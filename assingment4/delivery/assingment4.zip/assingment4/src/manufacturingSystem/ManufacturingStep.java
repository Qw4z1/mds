/**
 */
package manufacturingSystem;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Manufacturing Step</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see manufacturingSystem.ManufacturingSystemPackage#getManufacturingStep()
 * @model
 * @generated
 */
public interface ManufacturingStep extends Step {
} // ManufacturingStep
