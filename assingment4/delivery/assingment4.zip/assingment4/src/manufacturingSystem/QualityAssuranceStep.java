/**
 */
package manufacturingSystem;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Quality Assurance Step</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see manufacturingSystem.ManufacturingSystemPackage#getQualityAssuranceStep()
 * @model
 * @generated
 */
public interface QualityAssuranceStep extends Step {
} // QualityAssuranceStep
