/**
 */
package system;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Manufacturing</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see system.SystemPackage#getManufacturing()
 * @model
 * @generated
 */
public interface Manufacturing extends Step {
} // Manufacturing
