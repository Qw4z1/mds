/**
 */
package system;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Quality Assurance</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see system.SystemPackage#getQualityAssurance()
 * @model
 * @generated
 */
public interface QualityAssurance extends Step {
} // QualityAssurance
