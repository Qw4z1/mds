/**
 */
package system;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Transport</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see system.SystemPackage#getTransport()
 * @model
 * @generated
 */
public interface Transport extends Step {
} // Transport
